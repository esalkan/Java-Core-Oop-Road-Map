package assignments.Core.assignment_3_arithmeticOperators;

/**
 * @author esalkan
 */
public class Question_02 {

	/**
	 * @param args
	 */

	// Write a Java program that displays the area of a rectangle
	// with a width of 4.5 and a height of 7.9 using the following formula:
	//
	// area = width * height

	public static void main(String[] args) {

		System.out.println("+-------------------------------------------+");
		System.out.println("+            Week 2 Assignment              +");
		System.out.println("+               Question 2                  +");
		System.out.println("+       Area Calculator For Rectangle       +");
		System.out.println("+              Given Values                 +");
		System.out.println("+        width = 4.5   height = 7.9         +");
		System.out.println("+-------------------------------------------+");

		double width = 4.5, height = 7.9;
		double area = width * height;

		System.out.println("\nArea is : " + area);

	}

}
