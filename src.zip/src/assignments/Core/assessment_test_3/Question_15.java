package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// What will be the output of this code?

		int i = 0;

		while (i < 3) {
			System.out.println("hi");
			i++;
		}

		System.out.println("bye");
	}

}
