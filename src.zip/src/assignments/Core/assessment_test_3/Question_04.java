package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_04 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// How many times will the following code print "Hello World" ?

		for (int i = 0; i < 10; i++) {
			System.out.println("Hello World");
		}
	}

}
