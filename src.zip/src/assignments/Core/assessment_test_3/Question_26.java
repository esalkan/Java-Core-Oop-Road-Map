package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_26 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed
		// What's the result of the following code fragment?

		// int Value = 1; // Line 1
		//
		// switch (Value) { // Line 2
		// case Value: // Line 3
		// System.out.println("One");
		// break;
		// default:
		// System.out.println("Invalid");
		// break;
		// }

		/*
		 * - compile error at line 1 - compile error at line 3 - one - compile error at
		 * line 2 - invalid
		 */
	}

}
