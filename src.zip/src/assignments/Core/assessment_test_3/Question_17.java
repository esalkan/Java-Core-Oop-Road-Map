package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_17 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// What will be the output of this code?

		int x = 20;

		while (x > 0) {
			do {
				x -= 2;
			} while (x > 5);
		}

		x--;

		System.out.println(x);
	}

}
