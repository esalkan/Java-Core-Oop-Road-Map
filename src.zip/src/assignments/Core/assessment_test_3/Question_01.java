package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved and Passed

		// The loop is to run 10 times. Fill in the blank, using either of the 2
		// acceptable ways to specify the number of loops.

		// for(int i=0;___________;i++){}
		//
		// NOTE: Only write the missing part in the code, and do not type any space

		for (int i = 0; i < 10; i++) {
			System.out.println(i);
		}
	}

}
