package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved

		// Fill in the blank that Runs it 3 times using > to specify how many loops.
		// Decrement it with each iteration.

		// for (int i = 0; i >_____; i--) {}

		for (int i = 0; i > -3; i--) {
			System.out.println(i);
		}
	}

}
