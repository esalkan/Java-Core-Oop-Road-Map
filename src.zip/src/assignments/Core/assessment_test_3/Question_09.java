package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_09 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// Which of the following loops prints "Welcome to Java" 10 times?

		// for (int count = 1; count < 10; count++) {
		// System.out.println("Welcome to Java");
		// }
		//
		// for (int count = 0; count <= 10; count++) {
		// System.out.println("Welcome to Java");
		// }
		//
		for (int count = 1; count <= 10; count++) {
			System.out.println("Welcome to Java");
		}
		//
		// for (int count = 2; count < 10; count++) {
		// System.out.println("Welcome to Java");
		// }
	}

}
