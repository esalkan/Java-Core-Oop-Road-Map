package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// What will be the output when running the following program?

		int i = 0;
		int j;
		for (j = 0; j < 10; j++) {
			i++;
		}

		System.out.println(i + " " + j);
	}

}
