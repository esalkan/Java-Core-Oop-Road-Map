package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_28 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Not Passed

		// Which modification enables the code fragment to print : True Done?

		// boolean opt = true;
		//
		// switch (opt) { // Error
		// case true:
		// System.out.println("True");
		// break;
		// default:
		// System.out.println("False");
		// }
		// System.out.println("Done");

		// Change Boolean opt = true;
		// Replace String opt = "true"

		// Change case true:
		// Replace case "true":

	}

}
