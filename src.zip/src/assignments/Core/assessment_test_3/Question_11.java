package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_11 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

//		// Solved & Not Passed
//		
//		// What will be the output of this code?
//		
//		do {
//			System.out.println("100");
//		} while (true);
//		
//		System.out.println("Bye");
//		
//		// error in the code  !!! Why???

	}

}
