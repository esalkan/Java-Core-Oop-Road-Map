package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_20 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed

		// What will be the output of this code?

		int i1 = 1, i2 = 2, i3 = 4;
		i2 = i3 % 3;
		int i4 = i1 + (i2 * i3) + i3;
		System.out.println(i4);
	}

}
