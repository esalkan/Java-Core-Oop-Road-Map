package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_27 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed
		// What will be the output of this code?

		// long z = 10;
		//
		// switch (z) { // Here is the error
		// case 10:
		// System.out.println("Monday");
		// case 11:
		// System.out.println("Tuesday");
		// case 12:
		// System.out.println("Wednesday");
		// default:
		// System.out.println("Friday");
		// }

		// Answer : Compilation fails
	}

}
