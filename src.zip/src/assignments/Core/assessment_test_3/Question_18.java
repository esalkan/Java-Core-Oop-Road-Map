package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_18 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Not Passed

		// What will be the output of this code?

		int x = 0;
		while (x++ < 10) {

		}

		if (x > 10) {
			System.out.println("Greater" + "," + x);
		} else {
			System.out.println("Not Greater than" + "," + x);
		}
	}

}
