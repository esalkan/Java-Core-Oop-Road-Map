package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_30 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed
		// What will be the output of this code?

		// int x = 0;
		// while (x++ < 10) {
		// String message = x > 10 ? "Greater than" : false; // line 4
		// System.out.println(message + "," + x); // Line 5
		// }

		// The code will not compile because of line 4
		// The code will not compile because of line 5
		// Greater than,10
		// Greater than,11
		// false,10
		// false,11
	}

}
