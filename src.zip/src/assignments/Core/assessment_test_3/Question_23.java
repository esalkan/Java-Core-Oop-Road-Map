package assignments.Core.assessment_test_3;

/**
 * @author esalkan
 */
public class Question_23 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved & Passed
		// What will be the output of this code?

		int k = 2;
		do {
			System.out.println(k);
		} while (k-- > 0);
	}

}
