package assignments.Core;

/**
 * @author esalkan
 *
 */
public class notes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
