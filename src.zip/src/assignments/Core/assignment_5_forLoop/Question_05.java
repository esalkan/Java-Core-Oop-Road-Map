package assignments.Core.assignment_5_forLoop;

/**
 * @author esalkan
 */
public class Question_05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved

		// Print the table of 12 using for loop.

		int num = 12;

		for (int i = 1; i <= 10; i++) {
			System.out.println(num + " X " + i + " = " + i * num);
		}

	}

}
