package assignments.Core.assignment_5_forLoop;

/**
 * @author esalkan
 */
public class Question_01 {

	// Write a for loop that displays the following set of numbers:
	// 0,10,20,30,40,50,...1000
	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Solved

		for (int i = 0; i <= 1000; i += 10) {
			System.out.println(i);
		}
	}

}
