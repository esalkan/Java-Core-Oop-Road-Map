package assignments.Core.assignment_1_print_println;

/**
 * @author esalkan
 */
public class Question_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Alan, Turing ");
	}

}
