package assignments.Core.assignment_1_print_println;

/**
 * @author codesofmine
 */
public class Question_08 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("******        *************    **********");
		System.out.println("**    **             **        **");
		System.out.println("**     **            **        **");
		System.out.println("**      **           **        **");
		System.out.println("**      **    **     **        ********");
		System.out.println("**      **     **    **        **");
		System.out.println("**     **       **   **        **");
		System.out.println("**    **         **  **        **");
		System.out.println("*******           ****         **********");
	}

}
