package assignments.Core.assignment_1_print_println;

/**
 * @author esalkan
 */
public class Question_07 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(" /\\  /\\");
		System.out.println("/__\\/__\\");

		System.out.println("I'm from \"Germany\".");
		System.out.println("How is your day going on, \'good\' or \'bad\' ?");
	}

}
