package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_10 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// What will be the output of this code?

		boolean flag = false;

		if (false) {
			flag = !flag;
			System.out.println(flag);
		}
	}

}
