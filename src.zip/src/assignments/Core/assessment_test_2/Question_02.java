package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// What will be the output of this code?

		String string1 = "Java Exercises";
		String string2 = "do more " + string1;
		String string3 = string2;

		System.out.println("To able to be successful, we need to " + string3);
	}

}
