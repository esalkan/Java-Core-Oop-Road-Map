package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_15 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// What will be the output of this code?

		int a = 1 + 2 + 3 * 4;
		int b = 2 * 3 + 4;

		int total = a + b;

		System.out.println(total);

	}

}
