package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_25 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// In multi-branch if statement we can give as many
		// "else-if" statements as we want.

		// Answer = True
	}

}
