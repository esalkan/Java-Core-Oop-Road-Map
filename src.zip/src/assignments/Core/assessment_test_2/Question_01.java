package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// What will be the output of this code?

		int one = 1;
		String two = "2";

		System.out.println(two + 1 + one);
		System.out.println(one + 1 + two);
	}

}
