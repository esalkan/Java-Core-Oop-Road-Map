package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_26 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// When we declare if statement, it is mandatory to give the else block

		// Answer = No
	}

}
