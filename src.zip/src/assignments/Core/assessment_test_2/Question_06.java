package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_06 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// What will be the output of this code?

		int x1 = 50;
		int x2 = 75;

		boolean b = x1 >= x1;

		if (b = true) {
			System.out.println("Success");
		} else {
			System.out.println("Failure");
		}
	}

}
