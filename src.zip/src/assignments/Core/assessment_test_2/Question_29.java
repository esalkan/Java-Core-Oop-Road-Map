package assignments.Core.assessment_test_2;

/**
 * @author esalkan
 */
public class Question_29 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// What should be the condition in below code to able to print 123?

//		switch(condition) {
//		case 1:
//			System.out.println("1");
//			break;
//		case 2:
//			System.out.println("2");
//			break;
//		case 3:
//			System.out.println("3");
//			break;
//		}

		// Answer : non of the above 1,2,3....
	}

}
