package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_05 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and initialize two variables called first and second.
		// Write a single statement that will print the message "first is " followed by
		// the value of first,
		// And then space, followed by "second is ", followed by the value of the
		// second.

		int first = 1;
		int second = 2;

		System.out.println("first is : " + first + ", " + "second is : " + second);

	}

}
