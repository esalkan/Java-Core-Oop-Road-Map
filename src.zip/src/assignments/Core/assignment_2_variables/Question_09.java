package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_09 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare a byte variable named steps and assign 100
		// Declare a short variable named miles and assign 5000
		// Declare an int variable named count and assign 1000000
		// Declare a long variable named population and assign 3434455667

		byte steps = 100;
		short miles = 5000;
		int count = 1000000;
		long population = 3434455667l;

		System.out.println("Steps (steps) : " + steps);
		System.out.println("Miles (miles) : " + miles);
		System.out.println("Count (count) : " + count);
		System.out.println("Population (long) : " + population);
	}

}
