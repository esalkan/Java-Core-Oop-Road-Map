package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_04 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Assume that word is a String variable and already has a value.
		// Write a statement to display the message "Today's Word-Of-The-Day is: "
		// followed by the value of the word.
		// The message and the value of word should appear together, on a single line.

		String word = "String";
		String message = "Today's Word-Of-The-Day is : ";

		System.out.println(message + word);
	}

}
