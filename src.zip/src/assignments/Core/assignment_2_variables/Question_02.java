package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_02 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and initialize a String variable called message,
		// And write a statement to display its value to console.

		String message = "Maraba Zalım Dunya / Hello Cruel World!";

		System.out.println(message);

	}

}
