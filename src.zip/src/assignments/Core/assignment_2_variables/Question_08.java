package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_08 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and assign 2 String variables.
		// They will hold different programming language names.
		//
		// Using those variables print the message exactly like below.
		//
		// I will learn Java and SQL at CybertekSchool.

		String sql = "SQL";
		String java = "Java";

		System.out.println("I will learn " + java + " and " + sql + " at Cydeo");
	}

}
