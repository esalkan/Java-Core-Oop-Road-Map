package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_07 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and initialize an integer variable i and a floating-point variable f.
		// Write a statement that writes both of their values to console in the
		// following format:
		// i=value-of-i , f=value-of-f

		int i = 54;
		float f = 54.61f;

		System.out.println("i=" + i + " , f=" + f);
	}

}
