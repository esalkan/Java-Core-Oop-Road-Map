package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_01 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and initialize an integer variable called count,
		// And write a statement that displays the value of count on the console

		int count = 54;
		System.out.println("Count is : " + count);
	}

}
