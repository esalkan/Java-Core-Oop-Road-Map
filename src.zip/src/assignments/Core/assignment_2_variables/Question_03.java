package assignments.Core.assignment_2_variables;

/**
 * @author esalkan
 */
public class Question_03 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare two variables. One of them integer called num and the other one is
		// double called cost.
		// Print both values (num first, then cost), separated by a space on a single
		// line.

		int num = 54;
		double cost = 61.54;

		System.out.println("Num is : " + num + " Cost is : " + cost);

	}

}
