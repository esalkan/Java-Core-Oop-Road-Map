package assignments.Core.assignment_6_nestedForLoop_level_extraSpicy;

/**
 * @author esalkan
 */
public class Question_6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Write a Java program to print the following pattern

		// 1
		// 2 6
		// 3 7 10
		// 4 8 11 13
		// 5 9 12 14 15

	}

}
