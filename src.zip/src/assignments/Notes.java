package assignments;

/**
 * @author esalkan
 *
 */
public class Notes {

}
