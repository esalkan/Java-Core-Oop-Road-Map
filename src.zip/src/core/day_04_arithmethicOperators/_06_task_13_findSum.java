package core.day_04_arithmethicOperators;

/**
 * @author esalkan
 *
 */
public class _06_task_13_findSum {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int num1, num2, sum;
		num1 = 200;
		num2 = 100;
		sum = num1 + num2;

		System.out.println(num1 + " + " + num2 + " = " + sum);
	}

}
