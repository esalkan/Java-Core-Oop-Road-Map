package core.day_04_arithmethicOperators;

/**
 * @author esalkan
 *
 */
public class _08_task_15_convertMileToKilometer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double mile, km, convertingToKm;
		mile = 85.0;
		convertingToKm = mile * 1.609344;
		km = convertingToKm;

		System.out.println(mile + "Mile is equal to " + km + "Km");
	}

}
