package core.day_04_arithmethicOperators;

/**
 * @author esalkan
 *
 */
public class _10_task_17_calculateAverage {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double average;
		int num1, num2, num3;
		num1 = 15;
		num2 = 30;
		num3 = 50;

		average = (num1 + num2 + num3) / 3;
		System.out.println("Number 1 is : " + num1);
		System.out.println("Number 2 is : " + num2);
		System.out.println("Number 3 is : " + num3);
		System.out.println("Average of the 3 number is :" + average);
	}

}
