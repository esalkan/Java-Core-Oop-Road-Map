package core.day_04_arithmethicOperators;

/**
 * @author esalkan
 *
 */
public class _07_task_14_convertFahrenheitToCelcius {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		double fahrenheit, celcius;
		celcius = 70.2;
		fahrenheit = 9 * celcius / 5 + 32;

		System.out.println(celcius + " Celcius is equal to = " + fahrenheit + " Fahrenheit");
	}

}
