package core.day_28_Arrays_Part_5;

/**
 * @author esalkan
 *
 */
public class _01_Arrays {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
