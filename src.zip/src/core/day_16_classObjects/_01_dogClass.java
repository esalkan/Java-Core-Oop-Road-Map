package core.day_16_classObjects;

/**
 * @author esalkan
 */
public class _01_dogClass {

	String breed;
	int age;
	String color;
	String name;

	public void barking() {
		System.out.println(name + " is barking.");
	}

	public void hungry() {
		System.out.println(name + " is hungry.");
	}

	public void sleeping() {
		System.out.println(name + " is sleeping.");
	}

}
