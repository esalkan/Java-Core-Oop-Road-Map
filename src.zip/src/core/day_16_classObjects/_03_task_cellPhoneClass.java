package core.day_16_classObjects;

/**
 * @author esalkan
 */
public class _03_task_cellPhoneClass {

	String brand;
	double screenSize;
	String color;
	double price;

	public void call() {
		System.out.println("Calling....");
	}

	public void message() {
		System.out.println("Sending txt message....");
	}

	public void takeAphoto() {
		System.out.println("Taking a photo");
	}
}
