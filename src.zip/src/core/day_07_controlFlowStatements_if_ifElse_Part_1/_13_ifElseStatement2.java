package core.day_07_controlFlowStatements_if_ifElse_Part_1;

/**
 * @author esalkan
 *
 */
public class _13_ifElseStatement2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int score = 60;

		if (score >= 70) {
			System.out.println("Excelent");
			System.out.println("You Passed With Grade A");
		} else {
			System.out.println("Your Score is  : " + score);
			System.out.println("You fail");
		}

	}

}
