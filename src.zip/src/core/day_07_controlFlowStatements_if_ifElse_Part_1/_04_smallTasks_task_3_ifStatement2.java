package core.day_07_controlFlowStatements_if_ifElse_Part_1;

/**
 * @author esalkan
 *
 */
public class _04_smallTasks_task_3_ifStatement2 {

	/**
	 * @param args
	 */

	// Write an if statement that sets the variable fees to 50 if the Boolean
	// variable max is true

	public static void main(String[] args) {

		boolean max = false;
		int fee = 20;

		if (max) {
			fee = 50;
		}

		System.out.println("Fee is " + fee);

	}

}
