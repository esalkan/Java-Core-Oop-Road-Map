package core.day_07_controlFlowStatements_if_ifElse_Part_1;

/**
 * @author esalkan
 *
 */
public class _06_smallTasks_task_5_ifStatement2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// 5- Write an if statement that prints Ideal Temp if the temp is
		// between 70 and 80

		int temperature = 75;

		if (temperature >= 70 && temperature <= 80) {
			System.out.println("Ideal Temp");
		}

	}

}
