package core.day_07_controlFlowStatements_if_ifElse_Part_1;

/**
 * @author esalkan
 *
 */
public class _07_task_24_ifStatements2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// Write a Java program
		// 1- Declare a variable and initialize user age
		// 2- Then the program will show if the user is eligible to vote.
		// A Person who is eligible to vote must be older than or equal to
		// 18 years old.

		int personAge = 39;

		if (personAge >= 18) {
			System.out.println("You are eligible to vote");
		}

	}

}
