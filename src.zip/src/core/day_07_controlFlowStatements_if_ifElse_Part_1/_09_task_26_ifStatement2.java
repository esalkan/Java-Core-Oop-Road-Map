package core.day_07_controlFlowStatements_if_ifElse_Part_1;

/**
 * @author esalkan
 *
 */
public class _09_task_26_ifStatement2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Write a Java program that will accept two numbers and check if two
		// numbers are equal or not.

		int num1 = 15;
		int num2 = 15;

		if (num1 == num2) {
			System.out.println("Numbers are equal.");
		}

		if (num1 != num2) {
			System.out.println("Numbers are not equal.");
		}

	}

}
