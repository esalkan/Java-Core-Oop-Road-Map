package core.day_09_controlFlowStatements_Part_3;

/**
 * @author esalkan
 *
 */
public class assestment_2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		boolean x = true;
		boolean y = !x == false;

		System.out.println(y);
	}

}
