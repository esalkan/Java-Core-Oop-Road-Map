package core.day_09_controlFlowStatements_Part_3;

/**
 * @author esalkan
 *
 */
public class _06_ifElseRules {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		if (true) {
			System.out.println("Hello");
		}
		else
			System.out.println("Bye");
			System.out.println("Nur");

	}

}
