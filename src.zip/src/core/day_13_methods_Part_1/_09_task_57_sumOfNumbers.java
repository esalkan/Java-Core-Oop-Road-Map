package core.day_13_methods_Part_1;

/**
 * @author esalkan
 */
public class _09_task_57_sumOfNumbers {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		sumNumbers();
	}

	public static void sumNumbers() {
		int num1 = 10;
		int num2 = 50;
		int num3 = 50;
		int sum = num1 + num2 + num3;
		System.out.println("Total is " + sum);
	}

}
