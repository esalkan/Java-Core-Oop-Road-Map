package core.day_13_methods_Part_1;

/**
 * @author esalkan
 */
public class _08_task_56_convertKM {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		convertKM();
	}

	public static void convertKM() {
		int mile = 80;
		double km = mile * 1.60934;
		System.out.println(mile + " mile = " + km + " km");
	}

}
