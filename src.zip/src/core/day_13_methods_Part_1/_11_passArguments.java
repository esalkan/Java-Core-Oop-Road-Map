package core.day_13_methods_Part_1;

/**
 * @author esalkan
 */
public class _11_passArguments {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		// double x = 10.45;
		
		int a = 10;
		
		displayValue(a);
		
		// displayValue((int) x);
		
		// displayValue(x*4);
	}

	public static void displayValue(int num1) {
		
		System.out.println("The value is " + num1);
		
	}
}
