package core.day_13_methods_Part_1;

/**
 * @author esalkan
 *
 */
public class _01_methodsNotes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * Void method doesn't return anything.
		 * 
		 * Methods only can created out of the main method just in class can be created.
		 */

	}

}
