package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _05_task_03_printExercise {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("Mike");
		System.out.println("Smith");

		System.out.println("England");
		System.out.println("Germany");

		System.out.println(" ");

		System.out.print("Hello");
		System.out.print("All");
		System.out.println("Friends");

		System.out.println("Hotel");
		System.out.println("McLeah");
		System.out.println(" ");
		System.out.println("This is EU7");

		System.out.println("This is " + "EU-7");
		System.out.println("I am from TURKEY");

		System.out.println("I " + "am " + "From " + "TURKEY");

		System.out.println(" \" ");
	}

}
