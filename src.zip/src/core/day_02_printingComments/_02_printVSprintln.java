package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _02_printVSprintln {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
