package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _01_helloWorld {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Print first message with JAVA
		System.out.println("Maraba Zalım Dunya! :)");
		System.out.println("Hello Cruel World! :)");
	}

}
