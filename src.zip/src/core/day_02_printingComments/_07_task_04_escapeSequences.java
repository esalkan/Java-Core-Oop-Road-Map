package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _07_task_04_escapeSequences {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		System.out.println("\"\\__/\"\n\nHe said \"Hello\".\n\nWould you like \'coffee\' or \'tea\'?");

		System.out.println("\n+-----------------------+\n");

		System.out.println("\"\\__/\"\n");
		System.out.println("He said \"Hello\".\n");
		System.out.println("Would you like \'coffee\' or \'tea\'?");
	}

}
