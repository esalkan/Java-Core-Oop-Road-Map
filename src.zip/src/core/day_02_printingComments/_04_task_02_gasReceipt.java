package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _04_task_02_gasReceipt {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println("+---------------------------+");
		System.out.println("|                           |");
		System.out.println("|       MCLEAN STORE        |");
		System.out.println("|   2019-06-19  04:38PM     |");
		System.out.println("|                           |");
		System.out.println("|   Gallons:        10.870  |");
		System.out.println("|   Price/gallon:  $ 2.089  |");
		System.out.println("|                           |");
		System.out.println("|   Fuel Total:    $ 22.71  |");
		System.out.println("|                           |");
		System.out.println("+---------------------------+");

	}

}
