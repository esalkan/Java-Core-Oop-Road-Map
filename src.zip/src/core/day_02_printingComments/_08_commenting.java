package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _08_commenting {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Author : ALKAN
		// Time : 16:02
		System.out.println("Hello World");

		/*
		 *  Multiply Comment Line
		 */
		
		
	}

}
