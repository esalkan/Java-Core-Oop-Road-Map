package core.day_02_printingComments;

/**
 * @author esalkan
 *
 */
public class _03_task_01_triangle {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// print a rectangle with print method
		System.out.println("    *");
		System.out.println("   * * ");
		System.out.println("  *   *");
		System.out.println(" *     *");
		System.out.println("*********");
	}

}
