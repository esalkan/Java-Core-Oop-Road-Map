package core.day_34_Constructors_PassingObjectsToMethods;

/**
 * @author esalkan
 *
 */
public class _03_Apple {

	String color = "Red";

	public void mA() {
		System.out.println(color);
	}
}
