package core.day_34_Constructors_PassingObjectsToMethods;

/**
 * @author esalkan
 *
 */
public class _02_LightTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		_01_Light l1 = new _01_Light();

		// JVM see new keyword - invoke constructor
		// Which constructor

	}

}
