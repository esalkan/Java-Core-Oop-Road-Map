package core.day_14_methods_Part_2;

/**
 * @author esalkan
 */
public class _07_task_62_calculateGreatest {

	// Write a method that accepts 3 numbers and displays the greatest one in the
	// console.
	// Sample Output: calculateGreatest(5,2,3) -- >5

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
