package core.day_14_methods_Part_2;

/**
 * @author esalkan
 */
public class _08_task_63_fahrenheitToCelciusConverter {

	// Write a function that accepts Fahrenheit and displays the Celcius in the
	// console.
	// Sample Output: calculateCelcius(32) -- > 0 calculateCelcius(50) --> 10

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
