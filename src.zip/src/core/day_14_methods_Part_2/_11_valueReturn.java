package core.day_14_methods_Part_2;

/**
 * @author esalkan
 */
public class _11_valueReturn {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		
		

	}


}
