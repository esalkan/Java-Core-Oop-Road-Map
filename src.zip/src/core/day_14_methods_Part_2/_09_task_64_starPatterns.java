package core.day_14_methods_Part_2;

/**
 * @author esalkan
 */
public class _09_task_64_starPatterns {

	// Write a program that accepts a number and print the star patterns according
	// to that number
	// Sample Output: printPattern(5);
	// *
	// **
	// ***
	// ****
	// *****

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
