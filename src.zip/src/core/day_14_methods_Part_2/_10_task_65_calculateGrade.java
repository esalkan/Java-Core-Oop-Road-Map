package core.day_14_methods_Part_2;

/**
 * @author esalkan
 */
public class _10_task_65_calculateGrade {

	// Write a method that accepts 3 grades and prints the grade according to the
	// below table
	// _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _
	// | Average | Grade |
	// ---------------------------------------
	// | 90-100 | A |
	// | 80-89 | B |
	// | 70-79 | c |
	// | 60-69 | D |
	// | 0-59 | E |
	// - - - - - - - - - - - - - - - - - - - -

	// Sample Output:
	// calculateGrade(100,100,100) - > A
	// calculateGrade(50,50,50) - >F

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

}
