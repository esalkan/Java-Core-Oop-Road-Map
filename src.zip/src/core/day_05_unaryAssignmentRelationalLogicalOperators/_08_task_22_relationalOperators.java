package core.day_05_unaryAssignmentRelationalLogicalOperators;

/**
 * @author esalkan
 *
 */
public class _08_task_22_relationalOperators {

	/**
	 * @param args
	 */
	public static void main(String[] args) {


		/*
		 * Task-22
		 * 
		 * Declare and Initialize 2 numbers.Program should display if the first number
		 * is greater than second number. Output should be in the following format:
		 * “First number number is greater than Second number – True/False”
		 * 
		 */

		int num1 = 27;
		double num2 = 26.129;

		boolean result = num1 > num2;

		System.out.println("int num1 = 27;\n" + "double num2 = 26.129;\n" + "\n" + "boolean result = num1 > num2;\n"
				+ "result is : " + result);

	}

}
