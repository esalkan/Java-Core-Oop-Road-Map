package core.day_05_unaryAssignmentRelationalLogicalOperators;

/**
 * @author esalkan
 *
 */
public class _05_task_21_unaryOperators {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 4;
		int y = x * 4 - x++;
		System.out.println(y);

	}

}
