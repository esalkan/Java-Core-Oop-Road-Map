package core.day_08_controlFlowStatements_elseIf_switchCase_Part_2;

/**
 * @author esalkan
 *
 */
public class _03_task_30_evenOddNumber {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Write a Java Program:
		// 1 Declare and initialize a number
		// 2 Display whether the number is an odd number or even number.

		int number = 8;

		if (number % 2 == 0) {
			System.out.println("Number:" + number + " is even number");
		} else {
			System.out.println("Number:" + number + " is odd number");
		}

	}

}
