package core.day_08_controlFlowStatements_elseIf_switchCase_Part_2;

/**
 * @author esalkan
 *
 */
public class _02_task_29_biggerNumber {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// Declare and initialize 2 variable numbers
		// Program should tell which number is bigger
		// ex: "Number1 number is greater than Number2 number"
		int num1 = 3;
		int num2 = 4;

		if (num1 > num2) {
			System.out.println("Number1 " + num1 + " is bigger than " + " Number 2 " + num2);
		} else {
			System.out.println("Number2 " + num2 + " is bigger than " + " Number 1 " + num1);
		}

	}

}
