/**
 * 
 */
package core.day_24_Arrays_Part_1;

/**
 * @author esalkan
 *
 */
public class _06_task_89_ShoppingList {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * Display each array element in the console by using for loop
		 */
		String[] shoppingList = { "cheese", "pumpkin", "bread", "eggs", "milk" };

		for (int i = 0; i < shoppingList.length; i++) {

			System.out.println(shoppingList[i]);
		}
	}
}
