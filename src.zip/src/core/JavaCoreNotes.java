package core;

/**
 * @author esalkan
 *
 */
public class JavaCoreNotes {

}
