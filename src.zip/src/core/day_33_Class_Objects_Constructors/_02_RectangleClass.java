package core.day_33_Class_Objects_Constructors;

/**
 * @author esalkan
 *
 */
public class _02_RectangleClass {

	// Creating variables.
	// Their default value is 0.00
	double length;
	double width;

	// Creating a Method without return without parameter
	public void getArea() {
		// Just print what we send the print method
		System.out.println(length * width);
	}
}
