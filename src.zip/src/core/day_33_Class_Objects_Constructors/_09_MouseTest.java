package core.day_33_Class_Objects_Constructors;

/**
 * @author esalkan
 *
 */
public class _09_MouseTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		_10_MouseClass mouse = new _10_MouseClass(15);

		mouse.print();

	}

}
