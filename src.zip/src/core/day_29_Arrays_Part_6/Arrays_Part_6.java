package core.day_29_Arrays_Part_6;

/**
 * @author esalkan
 *
 */
public class Arrays_Part_6 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
