package core.day_15_methodOverloading;

/**
 * @author esalkan
 */
public class _08_methodOverloading_2 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	}

	public static int method1(int num1, int num2) {

		return 5;

	}

	public static double method1(int num1, float num2) {

		return 5.2;

	}

}
