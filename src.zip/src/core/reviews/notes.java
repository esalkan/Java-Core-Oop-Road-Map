/**
 * 
 */
package core.reviews;

/**
 * @author esalkan
 *
 */
public class notes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
