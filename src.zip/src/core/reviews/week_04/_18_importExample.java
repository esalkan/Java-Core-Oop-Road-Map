package core.reviews.week_04;

import core.reviews.week_03.customMethod;

/**
 * @author esalkan
 */
public class _18_importExample {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		System.out.println(customMethod.getAgeInDays(35));
	}

}
