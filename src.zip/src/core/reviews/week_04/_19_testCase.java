package core.reviews.week_04;

/**
 * @author esalkan
 */
public class _19_testCase {
	// P.I.Q.: How Do You write a Test Case?

	String testCaseID;
	String testCaseDescription;
	int numberOfTestSteps;
	boolean isPassed;

	// HW : create more attributes and some actions
	// create a class with main method and create objects of TestCases
}
