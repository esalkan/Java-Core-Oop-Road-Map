package core.reviews.week_04;

/**
 * @author esalkan
 */
public class _12_local_Vs_Instance_Variables {
	int a; // instance variable

	public void showDifference() {
		int a = 5; // local variable
		System.out.println(a);
	}
}
