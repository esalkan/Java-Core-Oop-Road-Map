/**
 * 
 */
package core.reviews.week_02;

/**
 * @author esalkan
 *
 */
public class evenorOdd {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int number = 100;// check if this is even or not

		if (number % 2 == 0) {
			System.out.println("Even");
		} else {
			System.out.println("Odd");
		}

	}

}
