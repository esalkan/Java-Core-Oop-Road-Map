/**
 * 
 */
package core.reviews.week_02;

/**
 * @author esalkan
 *
 */
public class relationalOperators {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(100 > 1000); // false

		System.out.println('A' == 65); // true

		System.out.println(15 >= 15);

		System.out.println("---------Question from Discord-------------");

		int b = 2;
		boolean res = ++b == 2 || --b == 2 && --b == 2; //
		System.out.println(res);

	}

}
