package core.day_11_controlFlowStatements_Part_5;

/**
 * @author esalkan
 *
 */
public class _11_task_52_whileLoops {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		// İnitialize a variable with value 25
		// Write a loop that will print "in the loop" while variable is more than 10
		int i = 25;

		while (i > 10) {

			System.out.println("in the loop");

			i--;
		}
	}

}
