package core.day_11_controlFlowStatements_Part_5;

/**
 * @author esalkan
 *
 */
public class _04_task_47_nestedForLoops {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		for (int i = 0; i <= 6; i++) {

			for (int j = 0; j <= 6; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}

}
