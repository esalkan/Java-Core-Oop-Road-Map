package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _10_task_10_variablesDataTypes {

	/**
	 * @param args
	 */

	// Which of the followings are legal declarations?

	public static void main(String[] args) {

		// boolean b1, b2;
		// String s1= "1", s2;
		// double d1,double d2;
		// int i1; int i2;
		// int i3; i4;
	}

}
