package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _11_task_11_variablesDataTypes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int a, b, c;
		a = 10;
		b = 20;
		c = a;
		a = b;

		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}

}
