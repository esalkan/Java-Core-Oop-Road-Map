package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _08_task_08_variablesDataTypes {

	/**
	 * @param args
	 */

	public static void main(String[] args) {
		/**
		 * Write a Java Program code for: Assign the value "IN 1491 COLUMBUS SAILED THE
		 * OCEANBLUE" to an appropriate variable, write a program in Java to change the
		 * year in the statement above from 1491 to 1492.
		 */
		int date = 1492;
		String text = "IN " + date + " COLUMBUS SAILED THE OCEANBLUE";

		System.out.println(text);
	}

}
