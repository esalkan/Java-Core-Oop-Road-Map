package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _06_task_06_variablesDataTypes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int flightNum = 89, travelTime, departure = 10, distance;

		System.out.println(flightNum);
		// System.out.println(travelTime);
		System.out.println(departure);
		// System.out.println(distance);

		// the program will give an error. cause variable decelerated but not assigned
	}

}
