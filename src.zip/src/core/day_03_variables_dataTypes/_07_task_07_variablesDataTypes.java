package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _07_task_07_variablesDataTypes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int i1, i2;
		float f1;
		String s1;

		i1 = 10;
		i2 = 20;
		f1 = 12.5f;
		s1 = "Task-7";

		System.out.println(i1);
		System.out.println(i2);
		System.out.println(f1);
		System.out.println(s1);
	}

}
