package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _05_task_05_variablesDataTypes {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String name = "Eyüp Sabri ALKAN";
		int age = 40;
		boolean isStudent = true;

		System.out.println("Student name is " + name + " & " + age + " years old." + " & " + "is he enroll the course? "
				+ isStudent);
	}

}
