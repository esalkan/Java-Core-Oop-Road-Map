package core.day_03_variables_dataTypes;

/**
 * @author esalkan
 *
 */
public class _12_task_12_variablesDataTypes {

	/**
	 * @param args
	 */

	/*
	 * 
	 * 1- Declare a variable whose name is your first and last names combined, in
	 * camelCase
	 * 
	 * 2- Assign the variable your first and last names, as a string
	 * 
	 * 3- Print in the console, specifying the variable, not the string, as the
	 * message
	 * 
	 */

	public static void main(String[] args) {

		String firstLastName;
		firstLastName = "Eyüp Sabri ALKAN";

		System.out.println(firstLastName);
	}

}
