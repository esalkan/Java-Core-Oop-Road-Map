/**
 * 
 */
package core.day_21_stringManipulation_Part_3;

/**
 * @author esalkan
 *
 */
public class _02_String_toLowerCase {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/**
		 * toLowerCase() Method
		 * 
		 * --> toLowerCase() method returns the calling string value converted to lower
		 * case.
		 */

		String word = "AUTOMATION";
		System.out.println(word.toLowerCase());
	}

}
